#!/usr/bin/python
import datetime

months = [
    None,
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
]

while True:
    pres_lname = raw_input("Enter president's last name: ")

    if pres_lname == 'q':
        break

    if pres_lname == '':
        continue

    with open("../DATA/presidents.txt") as pres_file:

        for rec in pres_file:
            flds = rec.split(":")
            if flds[1] == pres_lname:
                byear = int(flds[3])
                bmonth = months.index(flds[4])
                bday = int(flds[5])
                if flds[6]:
                    alive = ''
                    dyear = int(flds[6])
                    dmonth = months.index(flds[7])
                    dday = int(flds[8])
                else:
                    alive = '*'
                    dyear = datetime.date.today().year
                    dmonth = datetime.date.today().month
                    dday = datetime.date.today().day

                birthdate = datetime.date(byear,bmonth,bday)
                deathdate = datetime.date(dyear,bmonth,bday)


                print "NAME: {0} {1}".format( flds[2],flds[1] )
                print "BIRTH: {0:02d}/{1:02d}/{2:02d}".format(bmonth, bday, byear)
                if not alive:
                    print "DEATH: {0:02d}/{1:02d}/{2:02d}".format(dmonth, dday, dyear)

                lifespan = deathdate - birthdate
                age = lifespan.days/365.25

                print "AGE {0:.2f}{1}".format(age, alive)
                print

