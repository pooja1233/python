
class UnknownKnightError(Exception):
    pass

class Knight(object):

    def __init__(self,name):
        self._name = name
        K = None
        try:
            K = open('../DATA/knights.txt')
            found = False
            for line in K:
                (name,title,color,quest,cmt) = line[:-1].split(":")
                if name == self._name:
                    self._title = title
                    self._color = color
                    self._quest = quest
                    self._comment = cmt
                    found = True
                    break
            if not found:
                raise UnknownKnightError("No such knight as '" + self._name + "'")   
        except IOError,e:
            print "ERROR!",e
        finally:
            if K:
                K.close()

    @property
    def Name(self):
        return self._name
            
    @property
    def Title(self):
        return self._title
            
    @property
    def FavoriteColor(self):
        return self._color
            
    @property
    def Quest(self):
        return self._quest
            
    @property
    def Comment(self):
        return self._comment
            

if __name__== "__main__":
    k1 = Knight("Arthur")
    print k1. Name, k1.FavoriteColor, k1.Comment, k1.Title

    k2 = Knight("Arthur")
    print k2.Name, k2.FavoriteColor, k2.Comment, k2.Title

    
    try:
        k3 = Knight("Hillary")
    except UnknownKnightError,e:
        print e
