#!/usr/bin/env python

from random import randint

for i in xrange(10):
    num = randint(1,15)
    print '*' * num
