#!/usr/bin/env python
"""

@author: jstrick
Created on Mon Apr  1 06:50:41 2013

"""
from president import President

months = ["","Jan","Feb","Mar","Apr","May","Jun",
   "Jul","Aug","Sep","Oct","Nov","Dec" ]

george = President(1)   # George Washington

george_bd = george.getBirthDay()

print "George was born on {0} {1}, {2}".format(
    months[george_bd.month],
    george_bd.day,
    george_bd.year
)

abe = President(16)
print "Abe's birth state was {0}".format(abe.getBirthState())
print "Abe's party was {0}".format(abe.getParty())
