from datetime import date as Date

ww2_start = Date(2016, 6, 19)
ww2_end = Date(1991, 6, 19)

elapsed_time =  ww2_start -ww2_end
print elapsed_time
