#!/usr/bin/env python
"""

@author: jstrick
Created on Tue Mar 19 17:26:07 2013

"""
import sys

gif_file_name = sys.argv[1]
with open(gif_file_name, 'rb') as gif_file:
    data = gif_file.read()

if data[:3] == 'GIF':
    height = ord(data[6]) + ord(data[7]) * 256
    width = ord(data[8]) + ord(data[9]) * 256
else:
    print "Not a GIF file"

print "{0}x{1}".format(height,width)