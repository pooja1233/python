#!/usr/bin/python

# list to hold all presidents (will be list of lists)
all_pres = []

with open("../DATA/presidents.txt","r") as PRES:
    for line in PRES:
        flds = line[:-1].split(":")
        all_pres.append(flds) # add list of fields

# sort by lname, fname
for flds in sorted(all_pres,key=lambda e: (e[1],e[2])):
    print flds[2],flds[1],flds[10]

