#!//usr/bin/python
import sys
import os

def syntax():
    print("syntax: keepnewest.py DIR EXTENSION NUM-TO-KEEP")
    sys.exit(1)

if len(sys.argv) != 4:
    syntax()

(start_dir,extension, num_to_keep) = sys.argv[1:]

try:
    num_to_keep = int(num_to_keep)
except ValueError as e:
    print "Invalid number {0}".format(num_to_keep)
    syntax()

files = [ os.path.join(start_dir,f) for f in os.listdir(start_dir) if f.endswith('.' + extension) ]

files = [ (f,os.path.getmtime(f)) for f in files ]

files.sort(key=lambda e: (e[1],e[0]),reverse=True)

print "files", files
print "num_to_keep", num_to_keep

for file_info in files[:num_to_keep]:
    # print "Deleting", file   # for debugging
    os.unlink(file_info[0])
