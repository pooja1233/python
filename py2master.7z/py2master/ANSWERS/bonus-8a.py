#!/usr/bin/env python
"""

@author: jstrick

"""
import re

from dvd import DVD
from cd import CD

# split on commas with optional white space
RX_COMMAS = re.compile(r'''\s*,\s*''')

 #              title, length, language, subjects, artists, quality rating
COMMON_RECORD = '{0} {1} {2} {3} {4} {5}'

#                              director, dolby, mpaa rating
DVD_RECORD = COMMON_RECORD + ' {6} {7} {8}'

#                             tracks
CD_RECORD = COMMON_RECORD + ' {6}'

with open('media_database.txt', 'w') as MEDIA:
    while True:
        media_type = raw_input('Enter media type (cd or dvd) or q to quit: ')

        if media_type == 'q':
            break

        if media_type == '':
            continue

        if media_type not in ('cd', 'dvd'):
            print "Invalid media type: please enter cd or dvd"
            print
            continue

        title = raw_input("Enter title: ")

        length = raw_input("Enter length in minutes and seconds as MM:SS: ")
        (length_minutes, length_seconds) = length.split(':')

        language = raw_input("Enter language: ")

        raw_subjects = raw_input("Enter subjects, separated by commas: ")
        subjects = RX_COMMAS.split(raw_subjects)
        subjects_field = ';'.join(subjects)

        raw_artists = raw_input("Enter artists, separated by commas: ")
        artists = RX_COMMAS.split(raw_artists)
        artists_field = ';'.join(artists)

        rating = raw_input("Enter rating (A-F): ")

        if media_type == 'dvd':
            director = raw_input('Enter director: ')
            dolby = raw_input('Does the DVD have Dolby? (y/n): ')
            mpaa = raw_input('MPAA rating: ')
            media_record = DVD_RECORD.format(
                title,
                length,
                language,
                subjects_field,
                artists_field,
                rating,
            )
        elif media_type == 'cd':
            tracks = []
            while True:
                track_title = raw_input("\tEnter track title or q to quit: ")
                if track_title == 'q':
                    break

                if track_title == '':
                    continue

                track_artists = raw_input("\tEnter artists, separated by commas: ")
                track_length = raw_input("\tEnter track length (MM::SS): ")
                tracks.append(
                    '{0}/{1}/{2}'.format(
                        track_title,
                        track_artists,
                        track_length,
                    )
                )
                track_field = ';'.join(tracks)
                media_record = CD_RECORD.format(
                    title,
                    length,
                    language,
                    subjects_field,
                    artists_field,
                    rating,
                    track_field,
                )
        MEDIA.write(media_record + '\n')