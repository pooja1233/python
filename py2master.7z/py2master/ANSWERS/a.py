from subprocess import Popen,PIPE
from os import platform
class Pinger:
    def __init__(self,*ddresses):
        self.addresses = addresses

    def pingAll(self)
    
