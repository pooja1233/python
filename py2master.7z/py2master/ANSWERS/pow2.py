#!/usr/bin/python

for n in xrange(0,32):
	print "{0:2d} {1:10d}".format(n,2**n)

