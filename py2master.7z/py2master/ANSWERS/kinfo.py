#!/usr/bin/python

import sys
from knight import Knight, UnknownKnightError

for name in sys.argv[1:]:
    try:
        k = Knight(name)
    except UnknownKnightError as e:
        print e
        continue

    print "Name: {0} {1}".format(k.Title,name)
    print "Favorite Color:",k.FavoriteColor
    print "Quest:",k.Quest
    print "Comment:",k.Comment
    print
