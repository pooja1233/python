#!/usr/bin/python

print "xrange(1,6)"
for x in xrange(1,6):
	print x

print "xrange(6)"
for x in xrange(6):
	print x

print "xrange(3,12)"
for x in xrange(3,12):
	print x

print "xrange(5,30,5)"
for x in xrange(5,30,5):
	print x

print "xrange(10,1,-1)"
for x in xrange(10,0,-1):
	print x

print "xrange(30,0,-5)"
for x in xrange(30,5,-5):
	print x


