#!/usr/bin/python

try:
	x = 5
	y = "cheese"
	z = x + y
	f = open("sesame.txt")
	print "Bottom of try"

except (IOError,TypeError),e:
	print "Naughty programmer! ",e

