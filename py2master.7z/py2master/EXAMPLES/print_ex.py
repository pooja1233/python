#!/usr/bin/python

print "Hello, world"
print "#------------------------"

print "Hello,",
print "world"
print "#------------------------"

x = "Hello,"
y = "world"
print x,y
print "#------------------------"

print x,
print y

