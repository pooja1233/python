#!/usr/bin/env python

from datetime import (
    datetime as DateTime,
    date as Date,
    time as Time,
    timedelta as TimeDelta,
)

print "date.today():",Date.today()

now = DateTime.now()
print "datetime.now().day:", now.day
print "datetime.now().month:", now.month
print "datetime.now().year:", now.year
print "datetime.now().hour:", now.hour
print "datetime.now().minute:", now.minute
print "datetime.now().second:", now.second

d1 = DateTime(2008,6,13)
d2 = DateTime(2008,8,24)

d3 = d2 - d1

print "raw time delta:",d3
print "time delta days:",d3.days

interval = TimeDelta(10,0,0,0,0,0)
print "interval:",interval

d4 = d2 + interval
d5 = d2 - interval
print "d2 + interval:",d4
print "d2 - interval:",d5

t1 = DateTime(2008,8,24,10,4,34)
t2 = DateTime(2008,8,24,22,8,1)
t3 = t2 - t1

print "datetime(2008,8,24,10,4,34):",t1
print "datetime(2008,8,24,22,8,1):",t2
print "time diff (t2 - t1):",t3