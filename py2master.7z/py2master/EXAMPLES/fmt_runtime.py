#!/usr/bin/env python
"""

@author: jstrick
Created on Wed Mar 20 08:27:28 2013

"""

NAME = 'Guido'

FILLS = (' ', '*')
ALIGNMENTS = ('<', '>', '^')
WIDTHS = (5,10,20)

for fill in FILLS:
    print "fill is '{0}'".format(fill)
    for alignment in ALIGNMENTS:
        print "\talignment is '{0}'".format(alignment)
        for width in WIDTHS:
            print "\t\twidth is {0}".format(width)
            print '\t\t\t[{0:{1}{2}{3}}]'.format(NAME, fill, alignment, width)
    print
