#!/usr/bin/python
#print u'we spent \u20ac1.23M for an original C\u00e9zanne'
print u'26\u00B0'
print u'26\N{DEGREE SIGN}'
print u'26\u00B0\n'
print ur'26\u00B0\n'
print ur'26\N{DEGREE SIGN}'
