#!/usr/bin/env python
import urllib2

# note: fill in local proxy server
proxy = urllib2.ProxyHandler({'http': '127.0.0.1'})

opener = urllib2.build_opener(proxy)
urllib2.install_opener(opener)
google_url = urllib2.urlopen('http://www.google.com')

google_source = google_url.read()
print google_source