#!/usr/bin/python

try:
	x = 5
	y = "cheese"
	z = x + y
	print "Bottom of try"

except TypeError,e:
	print "Naughty programmer! ",e

print "After try-except"
