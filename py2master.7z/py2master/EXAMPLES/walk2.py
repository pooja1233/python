#!/usr/bin/env python

# find files whose size is greater than 100K bytes
import sys
import os

if sys.platform == 'win32':
    target = 'C:/Windows'
else:
    target = '/etc'

for currdir,subdirs,files in os.walk(target):
    for file in files:
        fullpath = os.path.join(currdir,file)
        try:
            fsize = os.path.getsize(fullpath)
        except OSError as e:
            continue
        if fsize > 100000:
            print fullpath
