#!/usr/bin/python

try:
	x = 5
	y = "cheese"
	z = x + y
	print "Bottom of try"
finally:
	print "Don't know whether we had an exception"

