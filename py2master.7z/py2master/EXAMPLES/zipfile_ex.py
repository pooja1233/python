#!/usr/bin/env python
import zipfile

ztxt = zipfile.ZipFile("../DATA/textfiles.zip")

print ztxt.namelist()

print ztxt.read("fruit.txt")

ztxt.close()

znew = zipfile.ZipFile("example.zip","w")

znew.write("../DATA/fruit.txt")
znew.write("../DATA/alice.txt")

znew.close()
