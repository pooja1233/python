#!/usr/bin/python

a = 5
b = 10
c = 20.22
d = 0123
e = 0xdeadbeef
print "a,b,c",a,b,c
print "a + b",a+b
print "a + c",a+c
print "d",d
print "e",e
