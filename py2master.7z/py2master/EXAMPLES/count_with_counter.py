#!/usr/bin/python

from collections import Counter

counts = Counter()

with open("../DATA/breakfast.txt") as BR:

    for breakfast_item in BR:
        breakfast_item = breakfast_item.rstrip()
        counts[breakfast_item] += 1

for item,count in counts.iteritems():
    print item,count