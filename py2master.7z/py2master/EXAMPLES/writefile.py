#!/usr/bin/python

states = (
    'Virginia',
    'North Carolina',
    'Washington',
    'New York',
    'Florida',
    'Ohio',
)

with open("../TEMP/states.txt","w") as statefile:
    for state in states:
        statefile.write(state + "\n")
