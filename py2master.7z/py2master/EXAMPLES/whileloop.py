#!/usr/bin/python

while True:
    name = raw_input("Enter a name (or q to quit): ")
    if name.lower().startswith("q"):
        print "goodbye!"
        break
    print "welcome, ",name
