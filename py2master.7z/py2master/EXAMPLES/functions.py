#!/usr/bin/python

def hello():
    print "Hello, world"

def sqrt(n):
    return n ** .5

hello()

n = sqrt(2)
m = sqrt(1234)

print "m is ",m," n is",n
