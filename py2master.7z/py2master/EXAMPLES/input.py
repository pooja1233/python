#!/usr/bin/python
n = raw_input("What is your name: ")
q = raw_input("What is your quest? ")
print n,"seeks",q
num = int(raw_input("Enter number: "))
print "2 times",num,"is ",2 * num
