#!/usr/bin/env python
import sys
import os

if 'win' in sys.platform:
    print "Path extensions are:",os.environ.get('PATHEXT')
else:
    print "Login name is", os.environ.get('LOGNAME')