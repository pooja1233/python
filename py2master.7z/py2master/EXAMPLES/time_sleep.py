#!/usr/bin/env python
"""

@author: jstrick
Created on Mon Mar 11 12:40:48 2013

"""
import time

print "waiting...",
time.sleep(5)
print "done."

